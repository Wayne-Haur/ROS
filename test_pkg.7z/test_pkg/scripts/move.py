#!/usr/bin/env python
import rospy
import actionlib
import logging
from geometry_msgs.msg import PoseStamped
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import PoseWithCovarianceStamped
from std_msgs.msg import String
import os
import signal

# 设置 logging 模块的日志格式
#logging.basicConfig(format='%(message)s', level=logging.INFO)

# 目标位置字典
target_positions = {
    1: {"x": -6.43, "y": -1.80, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.69, "ow": 0.71},
    2: {"x": -6.23, "y": 3.30, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.707, "ow": 0.7},
    3: {"x": -3.0, "y": 1.0, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 1.0, "ow": 1.0},
    4: {"x": 0.93, "y": 2.81, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.511, "ow": 0.859},
    5: {"x": 4.67, "y": 2.62, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.93, "ow": 0.35},
    6: {"x": 5.95, "y": -1.37, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.915, "ow": 0.307},
    7: {"x": -4.11, "y": -3.81, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.09, "ow": 0.995}
}
robot_move = False

# 订阅 amcl_pose 并打印坐标的回调函数
def amcl_pose_callback(msg):
    position = msg.pose.pose.position  # 位置
    orientation = msg.pose.pose.orientation  # 方向
    global robot_move
    if robot_move == True:
        print(f"現在位置: x={position.x:.3f}, y={position.y:.3f}, z={position.z:.3f}")
        print(f"現在方向: x={orientation.x:.3f}, y={orientation.y:.3f}, z={orientation.z:.3f}, w={orientation.w:.3f}")

# 等待 move_base 和 AMCL 准备好
def wait_for_services():
    print("等待 move_base 服务启动...")
    try:
        rospy.wait_for_service('move_base', timeout=8)  # 等待 move_base 服务，最多等待 7 秒
        print("move_base 服务已启动!")
    except rospy.ROSException:
        # 不记录日志，仅打印错误信息
        print("move_base 服务未能启动，继续执行后续操作...")

    print("等待 AMCL 话题消息...")
    try:
        rospy.wait_for_message('/amcl_pose', PoseWithCovarianceStamped, timeout=1)  # 等待 AMCL 的 pose 消息，最多等待 1 秒
        print("AMCL 已启动并接收到消息!")
    except rospy.ROSException:
        # 不记录日志，仅打印错误信息
        print("AMCL 话题未能接收到消息，继续执行后续操作...")

    # 即使服务启动失败，也返回 True，表示继续程序执行
    return True

def send_goal_and_wait(target_id):
    rospy.init_node('move_robot_to_target', anonymous=True)

    # 等待 move_base 和 AMCL 服务准备好
    #if not wait_for_services():
        #print("未能成功连接到 move_base 或 AMCL 服务，程序继续执行...")  # 继续执行，不退出
        #return

    # 创建一个 actionlib 客户端，发布目标位置并监听机器人的状态
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
    print("Waiting for move_base action server...")
    client.wait_for_server()

    # 创建目标位置的 MoveBaseGoal 消息
    goal = MoveBaseGoal()

    if target_id in target_positions:
        target = target_positions[target_id]
        
        print(f"前往{target_id}房間  座標:x={target['x']:.3f}, y={target['y']:.3f}, z={target['z']:.3f}")
        global robot_move
        robot_move = True
        
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now()
        
        goal.target_pose.pose.position.x = target["x"]
        goal.target_pose.pose.position.y = target["y"]
        goal.target_pose.pose.position.z = target["z"]
        goal.target_pose.pose.orientation.x = target["ox"]
        goal.target_pose.pose.orientation.y = target["oy"]
        goal.target_pose.pose.orientation.z = target["oz"]
        goal.target_pose.pose.orientation.w = target["ow"]

        print(f"Sending robot to target {target_id} at position {goal.target_pose.pose.position.x}, {goal.target_pose.pose.position.y}")
        client.send_goal(goal)

        print("Waiting for robot to reach the goal...")
        client.wait_for_result()

        if client.get_state() == actionlib.GoalStatus.SUCCEEDED:
            robot_move = False
            print(f"機器人到達 {target_id} 號房間")
        else:
            robot_move = False
            print(f"機器人未到達 {target_id} 號房間")
    else:
        print(f"Invalid target ID: {target_id}. No such room.")

def user_input():
    rospy.Subscriber("/amcl_pose", PoseWithCovarianceStamped, amcl_pose_callback)
    while not rospy.is_shutdown():
        user_input = input("请输入房间号 (1-7)，输入 0 退出: ")
        try:
            target_id = int(user_input)
            if user_input == "0":
            	print("退出程序...")
            	terminate_launch()  # 关闭 launch 文件中的所有节点
            	rospy.signal_shutdown("用户请求退出")  # 关闭 ROS 节点
            	break

            elif 1 <= target_id <= 7:
                send_goal_and_wait(target_id)
            else:
                print("无效房间号，请输入 1-7 或 0 退出")
        except ValueError:
            print("无效输入，请输入数字 (1-7) 或 0 退出")

def terminate_launch():
    """终止 roslaunch 进程"""
    try:
        # 获取所有 roslaunch 进程的 PID
        pids = os.popen('pgrep -f "roslaunch"').read().strip().split('\n')
        
        # 如果有 PID 列表，则终止每一个
        if pids:
            for pid in pids:
                try:
                    os.kill(int(pid), signal.SIGINT)  # 发送中断信号以关闭 roslaunch
                    print(f"已终止 roslaunch 进程，PID: {pid}")
                except ValueError:
                    print(f"无法将 PID {pid} 转换为整数")
                except ProcessLookupError:
                    print(f"PID {pid} 不存在或已经结束")
        else:
            print("没有找到 roslaunch 进程")
    except Exception as e:
        print(f"停止 roslaunch 时发生错误: {e}")

if __name__ == '__main__':
    try:
        rospy.init_node('move_robot_to_target', anonymous=True)
        
        # 等待服务启动
        wait_for_services()
        
        # 进入用户输入逻辑
        user_input()
    except rospy.ROSInterruptException:
        pass

