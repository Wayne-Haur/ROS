#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped

# 房間與座標對應字典
room_coordinates = {
    1: {"x": -6.43, "y": -1.80, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.69, "ow": 0.71},
    2: {"x": -6.23, "y": 3.30, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.707, "ow": 0.7},
    3: {"x": -3.0, "y": 1.0, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 1.0, "ow": 1.0},
    4: {"x": 0.93, "y": 2.81, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.511, "ow": 0.859},
    5: {"x": 4.67, "y": 2.62, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": 0.93, "ow": 0.35},
    6: {"x": 5.95, "y": -1.37, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.915, "ow": 0.307},
    7: {"x": -4.11, "y": -3.81, "z": 0.0, "ox": 0.0, "oy": 0.0, "oz": -0.09, "ow": 0.995}
}

def room_callback(msg):
    room_number = int(msg.data)  # 確保從 Web 收到的是整數房間號碼
    rospy.loginfo(f"Received room number: {room_number}")

    # 查找對應的座標
    if room_number in room_coordinates:
        coordinates = room_coordinates[room_number]
        x, y, z = coordinates["x"], coordinates["y"], coordinates["z"]
        ox, oy, oz, ow = coordinates["ox"], coordinates["oy"], coordinates["oz"], coordinates["ow"]
        move_robot_to(x, y, z, ox, oy, oz, ow)
    else:
        rospy.logwarn(f"Unknown room number: {room_number}")

def move_robot_to(x, y, z, ox, oy, oz, ow):
    # 假設機器人使用 move_base 進行導航
    pub = rospy.Publisher('/move_base_simple/goal', PoseStamped, queue_size=10)

    goal = PoseStamped()
    goal.header.stamp = rospy.Time.now()
    goal.header.frame_id = "map"

    goal.pose.position.x = x
    goal.pose.position.y = y
    goal.pose.position.z = z
    goal.pose.orientation.x = ox
    goal.pose.orientation.y = oy
    goal.pose.orientation.z = oz
    goal.pose.orientation.w = ow

    # 發佈目標位置
    pub.publish(goal)
    rospy.loginfo(f"Moving robot to position ({x}, {y}, {z}) with orientation ({ox}, {oy}, {oz}, {ow})")

def listener():
    rospy.init_node('room_navigation', anonymous=True)
    rospy.Subscriber('/room_number', String, room_callback)
    rospy.spin()

if __name__ == '__main__':
    listener()

